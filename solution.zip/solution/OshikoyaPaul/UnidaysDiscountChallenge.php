<?php
namespace OshikoyaPaul;

class UnidaysDiscountChallenge
{
    private $priceRules;
    private $Items;
    private $basket = array();

    function __construct($pricingRules, $items)
    {
        $this->priceRules = $pricingRules;
        $this->Items = $items;
    }

    public function AddToBasket($item)
    {
        if(trim($item)!="")
        {
            $this->basket[] = $item;
        }
    }

    public function CalculateTotalPrice()
    {
        $priceCalculation = new PriceCalculation($this->priceRules, $this->basket);
        $priceCalculation->setDeliveryCharge(7);
        $priceCalculation->setFreeDeliveryThreshold(50);
        $priceCalculation->setItems($this->Items);
        $priceCalculation->calculate();

        return $priceCalculation;
    }

    public function clearBasket()
    {
        $this->basket = [];
    }
}
<?php
require_once 'OshikoyaPaul/Item.php';
require_once 'OshikoyaPaul/PricingRule.php';
require_once 'OshikoyaPaul/PriceCalculation.php';
require_once 'OshikoyaPaul/UnidaysDiscountChallenge.php';

use OshikoyaPaul\Item;
use OshikoyaPaul\PricingRule;
use OshikoyaPaul\UnidaysDiscountChallenge;

$items = array();
$items[] = new Item("A", 8);
$items[] = new Item("B", 12);
$items[] = new Item("C", 4);
$items[] = new Item("D", 7);
$items[] = new Item("E", 5);

$pricingRules = array(
    new PricingRule("A", "None"),
    new PricingRule("B", "2 for £20.00"),
    new PricingRule("C", "3 for £10.00"),
    new PricingRule("D", "Buy 1 get 1 free"),
    new PricingRule("E", "3 for the price of 2"),
);


$unidaysDiscountChallenge = new UnidaysDiscountChallenge($pricingRules, $items);

//test case None
$unidaysDiscountChallenge->AddToBasket("");
$result = $unidaysDiscountChallenge->CalculateTotalPrice();

$totalPrice = $result->getTotal();
$deliveryCharge = $result->getDeliveryCharge();
$overallTotal = $totalPrice + $deliveryCharge;

echo "Test Case : None <br/>";
echo "Total Price : ".$totalPrice."<br/>";
echo "Delivery Charge : ".$deliveryCharge."<br/>";
echo "Overall Total : ".$overallTotal."<br/>";
echo "<br/>";
echo "<br/>";

$unidaysDiscountChallenge->clearBasket();

//test case A
$unidaysDiscountChallenge->AddToBasket("A");
$result = $unidaysDiscountChallenge->CalculateTotalPrice();

$totalPrice = $result->getTotal();
$deliveryCharge = $result->getDeliveryCharge();
$overallTotal = $totalPrice + $deliveryCharge;

echo "Test Case : A <br/>";
echo "Total Price : ".$totalPrice."<br/>";
echo "Delivery Charge : ".$deliveryCharge."<br/>";
echo "Overall Total : ".$overallTotal."<br/>";
echo "<br/>";
echo "<br/>";

$unidaysDiscountChallenge->clearBasket();

//test case B
$unidaysDiscountChallenge->AddToBasket("B");
$result = $unidaysDiscountChallenge->CalculateTotalPrice();

$totalPrice = $result->getTotal();
$deliveryCharge = $result->getDeliveryCharge();
$overallTotal = $totalPrice + $deliveryCharge;

echo "Test Case : B <br/>";
echo "Total Price : ".$totalPrice."<br/>";
echo "Delivery Charge : ".$deliveryCharge."<br/>";
echo "Overall Total : ".$overallTotal."<br/>";
echo "<br/>";
echo "<br/>";

$unidaysDiscountChallenge->clearBasket();

//test case C
$unidaysDiscountChallenge->AddToBasket("C");
$result = $unidaysDiscountChallenge->CalculateTotalPrice();

$totalPrice = $result->getTotal();
$deliveryCharge = $result->getDeliveryCharge();
$overallTotal = $totalPrice + $deliveryCharge;

echo "Test Case : C <br/>";
echo "Total Price : ".$totalPrice."<br/>";
echo "Delivery Charge : ".$deliveryCharge."<br/>";
echo "Overall Total : ".$overallTotal."<br/>";
echo "<br/>";
echo "<br/>";

$unidaysDiscountChallenge->clearBasket();

//test case D
$unidaysDiscountChallenge->AddToBasket("D");
$result = $unidaysDiscountChallenge->CalculateTotalPrice();

$totalPrice = $result->getTotal();
$deliveryCharge = $result->getDeliveryCharge();
$overallTotal = $totalPrice + $deliveryCharge;

echo "Test Case : D <br/>";
echo "Total Price : ".$totalPrice."<br/>";
echo "Delivery Charge : ".$deliveryCharge."<br/>";
echo "Overall Total : ".$overallTotal."<br/>";
echo "<br/>";
echo "<br/>";

$unidaysDiscountChallenge->clearBasket();

//test case E
$unidaysDiscountChallenge->AddToBasket("E");
$result = $unidaysDiscountChallenge->CalculateTotalPrice();

$totalPrice = $result->getTotal();
$deliveryCharge = $result->getDeliveryCharge();
$overallTotal = $totalPrice + $deliveryCharge;

echo "Test Case : E <br/>";
echo "Total Price : ".$totalPrice."<br/>";
echo "Delivery Charge : ".$deliveryCharge."<br/>";
echo "Overall Total : ".$overallTotal."<br/>";
echo "<br/>";
echo "<br/>";

$unidaysDiscountChallenge->clearBasket();

//test case BB
$unidaysDiscountChallenge->AddToBasket("B");
$unidaysDiscountChallenge->AddToBasket("B");
$result = $unidaysDiscountChallenge->CalculateTotalPrice();

$totalPrice = $result->getTotal();
$deliveryCharge = $result->getDeliveryCharge();
$overallTotal = $totalPrice + $deliveryCharge;

echo "Test Case : BB <br/>";
echo "Total Price : ".$totalPrice."<br/>";
echo "Delivery Charge : ".$deliveryCharge."<br/>";
echo "Overall Total : ".$overallTotal."<br/>";
echo "<br/>";
echo "<br/>";

$unidaysDiscountChallenge->clearBasket();
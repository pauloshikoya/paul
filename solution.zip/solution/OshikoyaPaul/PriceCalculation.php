<?php
namespace OshikoyaPaul;

class PriceCalculation
{
    private $Total;
    private $DeliveryCharge;
    private $FreeDeliveryThreshold;

    /**
     * @var array PriceRule
     */
    private $PriceRules;
    private $Basket;

    /**
     * @var array Item
     */
    private $Items;

    /**
     * @return mixed
     */
    public function getFreeDeliveryThreshold()
    {
        return $this->FreeDeliveryThreshold;
    }

    /**
     * @param mixed $FreeDeliveryThreshold
     */
    public function setFreeDeliveryThreshold($FreeDeliveryThreshold)
    {
        $this->FreeDeliveryThreshold = $FreeDeliveryThreshold;
    }

    public function __construct($priceRules, $basket)
    {
        $this->PriceRules = $priceRules;
        $this->Basket = $basket;
    }

    public function calculate()
    {
        $total = 0;

        foreach ($this->Items as $item)
        {
            $numberOfOccurrence = $this->getNumberOfOccurrenceOfItemInBasket($item->getName());

            if($numberOfOccurrence>0)
            {
                foreach ($this->PriceRules as $priceRule)
                {
                    if($priceRule->getRuleName() == $item->getName())
                    {
                        if($priceRule->getDiscountName()=="None")
                        {
                            $total+=($numberOfOccurrence*$item->getPrice());
                        }
                        else if($priceRule->getDiscountName()=="2 for £20.00")
                        {
                            $remainder = $numberOfOccurrence % 2;
                            $divisionNumber = floor($numberOfOccurrence/2);
                            if($remainder>0)
                            {
                                $total+= ($remainder*$item->getPrice());
                            }

                            if($divisionNumber>0)
                            {
                                $total+= ($divisionNumber*20);
                            }

                        }
                        else if($priceRule->getDiscountName()=="3 for £10.00")
                        {
                            $remainder = $numberOfOccurrence % 3;
                            $divisionNumber = floor($numberOfOccurrence/3);
                            if($remainder>0)
                            {
                                $total+= ($remainder*$item->getPrice());
                            }

                            if($divisionNumber>0)
                            {
                                $total+= ($divisionNumber*10);
                            }
                        }
                        else if($priceRule->getDiscountName()=="Buy 1 get 1 free")
                        {
                            if($numberOfOccurrence==1)
                            {
                                $numberOfOccurrence++;
                                $this->Basket[] = $item->getName();
                            }

                            $remainder = $numberOfOccurrence % 2;
                            $divisionNumber = floor($numberOfOccurrence/2);
                            if($remainder>0)
                            {
                                $total+= ($remainder*$item->getPrice());
                            }

                            if($divisionNumber>0)
                            {
                                $total+= ($divisionNumber*$item->getPrice());
                            }
                        }
                        else if($priceRule->getDiscountName()=="3 for the price of 2")
                        {
                            $priceOf2 = (2*$item->getPrice());

                            $remainder = $numberOfOccurrence % 3;
                            $divisionNumber = floor($numberOfOccurrence/3);
                            if($remainder>0)
                            {
                                $total+= ($remainder*$item->getPrice());
                            }

                            if($divisionNumber>0)
                            {
                                $total+= ($divisionNumber*$priceOf2);
                            }
                        }
                        else
                        {
                            $total+=($numberOfOccurrence*$item->getPrice());
                        }
                    }
                }
            }
        }

        if($total>=$this->getFreeDeliveryThreshold())
        {
            $this->setDeliveryCharge(0);
        }


        if(empty($this->Basket)){
            $this->setDeliveryCharge(0);
        }

        $this->setTotal($total);
    }

    /**
     * @return mixed
     */
    public function getTotal()
    {
        return $this->Total;
    }

    /**
     * @param mixed $Total
     */
    private function setTotal($Total)
    {
        $this->Total = $Total;
    }

    /**
     * @return mixed
     */
    public function getDeliveryCharge()
    {
        return $this->DeliveryCharge;
    }

    /**
     * @param mixed $DeliveryCharge
     */
    public function setDeliveryCharge($DeliveryCharge)
    {
        $this->DeliveryCharge = $DeliveryCharge;
    }

    /**
     * @param mixed $SetItems
     */
    public function setItems($SetItems)
    {
        $this->Items = $SetItems;
    }

    /**
     * @param $itemName
     * @return int
     */
    public function getNumberOfOccurrenceOfItemInBasket($itemName)
    {
        $indexes = array_keys($this->Basket, $itemName); //array(0, 1)
        return count($indexes);
    }

}
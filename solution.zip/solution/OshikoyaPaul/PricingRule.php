<?php
namespace OshikoyaPaul;

class PricingRule
{
    private $DiscountName;
    private $RuleName;

    /**
     * PricingRule constructor.
     * @param $RuleName
     * @param $DiscountName
     */
    public function __construct($RuleName, $DiscountName)
    {
        $this->DiscountName = $DiscountName;
        $this->RuleName = $RuleName;
    }

    /**
     * @return mixed
     */
    public function getDiscountName()
    {
        return $this->DiscountName;
    }

    /**
     * @param mixed $DiscountName
     */
    public function setDiscountName($DiscountName): void
    {
        $this->DiscountName = $DiscountName;
    }

    /**
     * @return mixed
     */
    public function getRuleName()
    {
        return $this->RuleName;
    }

    /**
     * @param mixed $RuleName
     */
    public function setRuleName($RuleName): void
    {
        $this->RuleName = $RuleName;
    }


}